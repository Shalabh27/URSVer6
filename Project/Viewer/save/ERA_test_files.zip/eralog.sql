CREATE TABLE [dbo].[ERALog](
	[agency] [char](5) NOT NULL,
	[reportname] [varchar](50) NOT NULL,
	[version] [varchar](11) NOT NULL,
	[dt] [datetime] NOT NULL,
	[ran] [int] NOT NULL)